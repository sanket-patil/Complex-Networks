Please note that the settings files for version 4.0 of the PDF specfication are correct for version 4.01 of the specfication. For this reason additional settings were not created.

IEEE Content Managment